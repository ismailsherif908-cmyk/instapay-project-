#Mazen Hussien Ramadan ·Ismail Sherif Ismail
from validation import validate_username, validate_password, validate_phone

MAX_LOGIN_ATTEMPTS = 3

users = {}


def find_user(username):
    return users.get(username)


def register():
    print("\n===== Register =====")
    name = input("Full name: ").strip()

    while True:
        phone = input("Phone number: ").strip()
        ok, msg = validate_phone(phone)
        if ok:
            break
        print(msg)

    while True:
        username = input("Choose a username: ").strip()
        ok, msg = validate_username(username, users)
        if ok:
            break
        print(msg)

    while True:
        password = input("Choose a password (min 6 characters): ").strip()
        ok, msg = validate_password(password)
        if ok:
            break
        print(msg)

    users[username] = {
        "name": name,
        "phone": phone,
        "password": password,
        "balance": 0,
        "card": None,
        "transactions": [],
    }
    print(f"\nAccount created successfully! Welcome, {name}.")


def login():
    print("\n===== Login =====")
    attempts = 0
    while attempts < MAX_LOGIN_ATTEMPTS:
        username = input("Username: ").strip()
        password = input("Password: ").strip()

        user = find_user(username)
        if user and user["password"] == password:
            print(f"\nLogin successful!\nWelcome {user['name']}")
            return username

        attempts += 1
        remaining = MAX_LOGIN_ATTEMPTS - attempts
        if remaining > 0:
            print(f"Invalid username or password. {remaining} attempt(s) left.")
        else:
            print("Invalid username or password.")

    print("\nToo many failed attempts. Returning to main menu.")
    return None


def change_password(username):
    print("\n===== Change Password =====")
    user = users[username]

    old_password = input("Current password: ").strip()
    if old_password != user["password"]:
        print("Current password is incorrect.")
        return

    while True:
        new_password = input("New password (min 6 characters): ").strip()
        ok, msg = validate_password(new_password)
        if ok:
            break
        print(msg)

    user["password"] = new_password
    print("\nPassword changed successfully!")