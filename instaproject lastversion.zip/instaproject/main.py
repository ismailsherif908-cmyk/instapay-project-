#Mazen Hussien Ramadan ·Ismail Sherif Ismail

from auth import register, login, change_password
from operations import (
    show_balance,
    link_card,
    deposit,
    withdraw,
    transfer,
    show_transactions,
)


def main_menu(username):
    while True:
        print("\n===== Main Menu =====")
        print("1. View Balance")
        print("2. Link Card")
        print("3. Deposit")
        print("4. Withdraw")
        print("5. Transfer")
        print("6. Transaction History")
        print("7. Change Password")
        print("8. Logout")

        choice = input("Choose: ").strip()

        if choice == "1":
            show_balance(username)
        elif choice == "2":
            link_card(username)
        elif choice == "3":
            deposit(username)
        elif choice == "4":
            withdraw(username)
        elif choice == "5":
            transfer(username)
        elif choice == "6":
            show_transactions(username)
        elif choice == "7":
            change_password(username)
        elif choice == "8":
            print("\nLogged out successfully.")
            return
        else:
            print("Invalid choice. Please select 1-8.")


def start():
    while True:
        print("\n===== InstaPay =====")
        print("1. Register")
        print("2. Login")
        print("3. Exit")

        choice = input("Choose: ").strip()

        if choice == "1":
            register()
        elif choice == "2":
            username = login()
            if username:
                main_menu(username)
        elif choice == "3":
            print("\nGoodbye.")
            break
        else:
            print("Invalid choice. Please select 1-3.")


if __name__ == "__main__":
    start()