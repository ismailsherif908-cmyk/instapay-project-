#Mazen Hussien Ramadan ·Ismail Sherif Ismail


def validate_username(username, users):
    if not username or not username.strip():
        return False, "Username cannot be empty."
    if " " in username:
        return False, "Username cannot contain spaces."
    if username in users:
        return False, "Username already exists. Choose another one."
    return True, ""


def validate_password(password):
    if len(password) < 6:
        return False, "Password must be at least 6 characters long."
    return True, ""


def validate_phone(phone):
    if not phone.isdigit():
        return False, "Phone number must contain digits only."
    if len(phone) != 11:
        return False, "Phone number must be 11 digits long."
    if not phone.startswith(("010", "011", "012", "015")):
        return False, "Phone number must start with 010, 011, 012 or 015."
    return True, ""


def validate_amount(amount_str):
    try:
        amount = float(amount_str)
    except ValueError:
        return False, "Amount must be a number."
    if amount <= 0:
        return False, "Amount must be greater than 0."
    return True, ""


def validate_card_number(card_number):
    if not card_number.isdigit():
        return False, "Card number must contain digits only."
    if len(card_number) != 16:
        return False, "Card number must be 16 digits long."
    return True, ""


def validate_cvv(cvv):
    if not cvv.isdigit():
        return False, "CVV must contain digits only."
    if len(cvv) != 3:
        return False, "CVV must be exactly 3 digits."
    return True, ""


def validate_expiry(expiry):

    parts = expiry.split("/")
    if len(parts) != 2:
        return False, "Expiry date must be in MM/YY format."
    month, year = parts
    if not (month.isdigit() and year.isdigit()):
        return False, "Expiry date must be in MM/YY format."
    if len(month) != 2 or len(year) != 2:
        return False, "Expiry date must be in MM/YY format."
    if int(month) < 1 or int(month) > 12:
        return False, "Month must be between 01 and 12."
    return True, ""
