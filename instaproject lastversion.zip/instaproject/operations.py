#Mazen Hussien Ramadan ·Ismail Sherif Ismail

from validation import validate_amount, validate_card_number, validate_cvv, validate_expiry
from auth import users, find_user


def show_balance(username):
    user = users[username]
    print(f"\nCurrent Balance: {user['balance']} EGP")


def link_card(username):
    print("\n===== Link Visa Card =====")
    user = users[username]

    while True:
        card_number = input("Card number (16 digits): ").strip()
        ok, msg = validate_card_number(card_number)
        if ok:
            break
        print(msg)

    holder = input("Card holder name: ").strip()

    while True:
        expiry = input("Expiry date (MM/YY): ").strip()
        ok, msg = validate_expiry(expiry)
        if ok:
            break
        print(msg)

    while True:
        cvv = input("CVV (3 digits): ").strip()
        ok, msg = validate_cvv(cvv)
        if ok:
            break
        print(msg)
    user["card"] = {
        "number_last4": card_number[-4:],
        "holder": holder,
        "expiry": expiry,
    }
    print("\nCard linked successfully!")


def deposit(username):
    print("\n===== Deposit =====")
    user = users[username]

    while True:
        amount_str = input("Enter amount: ").strip()
        ok, msg = validate_amount(amount_str)
        if ok:
            break
        print(msg)

    amount = float(amount_str)
    user["balance"] += amount
    user["transactions"].append({"type": "Deposit", "amount": amount})
    print(f"\nDeposit successful!\nNew Balance: {user['balance']} EGP")


def withdraw(username):
    print("\n===== Withdraw =====")
    user = users[username]

    while True:
        amount_str = input("Enter amount: ").strip()
        ok, msg = validate_amount(amount_str)
        if not ok:
            print(msg)
            continue
        amount = float(amount_str)
        if amount > user["balance"]:
            print("Insufficient balance. You cannot withdraw more than you have.")
            continue
        break

    user["balance"] -= amount
    user["transactions"].append({"type": "Withdraw", "amount": -amount})
    print(f"\nWithdrawal successful!\nRemaining Balance: {user['balance']} EGP")


def transfer(username):
    print("\n===== Transfer =====")
    user = users[username]

    while True:
        recipient_name = input("Recipient: ").strip()
        recipient = find_user(recipient_name)
        if not recipient:
            print("Recipient does not exist.")
            continue
        if recipient_name == username:
            print("You cannot transfer money to yourself.")
            continue
        break

    while True:
        amount_str = input("Amount: ").strip()
        ok, msg = validate_amount(amount_str)
        if not ok:
            print(msg)
            continue
        amount = float(amount_str)
        if amount > user["balance"]:
            print("Insufficient balance.")
            continue
        break

    confirm = input("\nConfirm transfer? yes/no: ").strip().lower()
    if confirm != "yes":
        print("Transfer cancelled.")
        return

    user["balance"] -= amount
    recipient["balance"] += amount
    user["transactions"].append({"type": "Transfer", "amount": -amount, "to": recipient_name})
    recipient["transactions"].append({"type": "Transfer", "amount": amount, "from": username})

    print(f"\nTransfer successful!\nYour new balance: {user['balance']} EGP")


def show_transactions(username):
    print("\n===== Transaction History =====\n")
    user = users[username]
    transactions = user["transactions"]

    if not transactions:
        print("No transactions yet.")
        return

    for i, tx in enumerate(transactions, start=1):
        sign = "+" if tx["amount"] >= 0 else ""
        print(f"{i}. {tx['type']:<10} {sign}{tx['amount']} EGP")
